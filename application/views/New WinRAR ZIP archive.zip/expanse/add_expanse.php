<!doctype html>
<html class="fixed">
<head>
		<?php $this->load->view('common/header_link'); ?>
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/modal.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/Lobibox.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/notifications.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/vendor/custom-scrollbar/jquery.mCustomScrollbar.css">
    
    <style type="text/css">
        .form-group{
            padding: 0px 2px;
        }
        
    </style>
</head>
<body>
		<div class="preloader-single shadow-inner mg-b-30" id="my_loader" style="position:fixed; background: rgba(0,0,0,0.8); width:100%; height:100vh; z-index: 9999; display:none;">
        <div class="ts_preloading_box" style="">
            <div id="ts-preloader-absolute09" style="position:fixed; margin:auto;   border-radius:70px;">
                <div class="tsperloader9" id="tsperloader9_one"></div>
                <div class="tsperloader9" id="tsperloader9_two"></div>
                <div class="tsperloader9" id="tsperloader9_three"></div>
                <div class="tsperloader9" id="tsperloader9_four"></div>
            </div>
        </div>
    </div>
    
    <?php $this->load->view('common/sidemenu'); ?>
    <div class="all-content-wrapper">
        
        <?php $this->load->view('common/titlebar'); ?>
		
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding:0px;">
            <div class="container-fluid" style="margin-top:15px;">
               <div class="product-status-wrap mycard">
			    <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div id="myheadtitle" style=" ">
                                Add Expanse
                               <ul class="my_quick_bt" style="">
                                    
                                    <li>
                                        <a href="<?php echo base_url(); ?>team">
                                            <i class="ion-ios-undo-outline"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="panel-body " style="padding:0px;">
								  <form class="form-horizontal form-bordered" action="" method="post">
                                      <div class="row">
                                        <div class="col-md-12">
										<div class="col-md-3">
											<div class="form-group">
												
													<select class="form-control" name="expanse_head" id="category" required>
														<option value="">Expanse Head</option>
														<?php foreach($category_list as $row){ ?>
														<option value="<?php echo $row->expanse_head_id ?>" <?php if(isset($expanse_selected)){ if($expanse_selected[0]->expanse_head_id == $row->expanse_head_id){ echo 'selected'; }} ?>  ><?php echo $row->expanse_head_name; ?></option>
													 <?php } ?>
													</select>
												
											</div>
						       </div>
									 <div class="col-md-3"  >
										 <div class="form-group">
											
												 <select class="form-control" name="expanse_subhead" >
													  <option value="" class="op_default">Expanse Subhead</option>
													 <?php foreach($subcategory_list as $row){ ?>
													 <option value="<?php echo $row->expanse_subhead_id ?>" <?php if(isset($expanse_selected)){ if($expanse_selected[0]->expanse_subhead_id == $row->expanse_subhead_id){ echo 'selected'; }} ?> class="op_<?php echo $row->expanse_head_id; ?>" ><?php echo $row->expanse_subhead_name; ?></option>
													<?php } ?>
												 </select>
											 </div>
										 
									</div>
                                   <div class="col-md-3">
                                      
										<div class="form-group">
                                              <input type="hidden" value="<?php if(isset($expanse_selected[0])){ echo $expanse_selected[0]->expanse_date; } ?>" id="my_date">
                                            
												<input type="date" class="form-control" name="expanse_date" value=" 01-05-2021" placeholder="Expanse Date" required>
										</div>
								   </div>    
            
								 <div class="col-md-3">
									 <div class="form-group">
										
											 <input type="number" step="0.01" class="form-control" name="expanse_amount" value="<?php if(isset($expanse_selected[0])){ echo $expanse_selected[0]->expanse_amount; } ?>" placeholder="Expanse Amount" required>
										
									 </div>
								  </div>
                                         
									
                                     
                                    <div class="col-md-12">
											 <div class="form-group">
												
                                                     <textarea class="form-control" name="note" placeholder="Note" style="height:50px;"><?php if(isset($expanse_selected[0])){ echo $expanse_selected[0]->note; } ?></textarea>
											
											</div>
						             </div>         
                                </div>
                                   
                                    <div class="col-md-12">  
									<div class="col-md-1">
											<div class="form-group">
											
													<input type="submit" class="btn btn-primary" name="submit" value="submit" style=" width:100%;">
												
											</div>
						            </div>
									<div class="col-md-1">
											<div class="form-group">
												
												<a href="<?php echo base_url(); ?>expanse/add_expanse">	<button type="button" class="btn-transparent btn-red"  style=" width:100%; height:35px;">Cancel</button></a>
												
											</div>
						            </div>
                                      </div>
                                      </div>
									</form>
							</div>
                              
					</div>
                </div>
               </div>
            </div>
            </div> 
        

	</div>
<?php $this->load->view('common/footer_script'); ?>
<script src="<?php echo base_url(); ?>/catalogs/assets/javascripts/image-compressor.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/Lobibox.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/notification-active.js">
</script>
 <script src="<?php echo base_url(); ?>/catalogs/js/image_compress/image-compressor.js"></script>    
<script src="<?php echo base_url(); ?>/catalogs/assets/vendor/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
     function setInputDate(){
    var _dat = $('#my_date').val();
    var hoy = new Date(_dat),
        d = hoy.getDate(),
        m = hoy.getMonth()+1, 
        y = hoy.getFullYear(),
        data;

    if(d < 10){
        d = "0"+d;
    };
    if(m < 10){
        m = "0"+m;
    };

    data = y+"-"+m+"-"+d;
    console.log(data);
    $('input[name=expanse_date]').val(data);
};

setInputDate();
        
        
    $(document).on('change','select[name=expanse_head]',function(){
       
        val = $('select[name=expanse_head]').val();
        
        var show_op = 'op_'+val;
        
        $('select[name=expanse_subhead]').val('');
        $('select[name=expanse_subhead] option').hide();
        
        
        $('select[name=expanse_subhead] option.op_default').show();
        $('select[name=expanse_subhead] option.'+show_op).show();
        
    });   
        
    function sub_head_option(){
        
        val = $('select[name=expanse_head]').val();
        
        var show_op = 'op_'+val;
        
        
        $('select[name=expanse_subhead] option').hide();
        
        
        $('select[name=expanse_subhead] option.op_default').show();
        $('select[name=expanse_subhead] option.'+show_op).show();
    }  
        
        
    sub_head_option();    
});
</script>
</body>
</html>
