<!doctype html>
<html class="fixed">
<head>
		<?php $this->load->view('common/header_link'); ?>
       
    
		 <style type="text/css">
        .form-group{
            padding: 0px;
        }    
        
       .form-group .form-control{
           
         width: 100%;  
         padding-left: 30px;
         border:1px solid #43444a;
       }
        .form-group .form-control:option{
            padding: 10px;
        }
        
        .status{
            margin-top: 3px;
            margin-bottom: 0px;
        }
        
        .search_input_i{
            width:30px;
            height: 35px;
            position: absolute;
            color: #0088cc;
            padding: 5px 9px;
        }
        
        .order_quick_detail{
            width:100%; height:auto; background:#232323;
            border: 1px solid #3e3e60;
            padding: 15px 10px;
            overflow: auto;
            
        }
        
        .order_quick_detail p{
            margin-bottom: 0px;
            color: #ffffff;
        }
             
             #table tbody tr td{
                 line-height: 25px;
             }     
             
             
            .message{
            width:100%;
            height:40px;

            padding-top:8px;
            text-align:center; color:red;
            box-shadow: 0px 3px 7px -1px rgba(0,0,0,0.6);
            display: none;

        } 
            .message.error{
              color: #ffffff;
             background-color: #e91e63;
             border:1px solid #e91e63;
        }
        .message.success{
             color: #ffffff;
             background-color: #4caf50;
             border:1px solid green;
        }
    </style>
</head>
<body>
		<div class="preloader-single shadow-inner mg-b-30" id="my_loader" style="position:fixed; background: rgba(0,0,0,0.8); width:100%; height:100vh; z-index: 9999; display:none;">
        <div class="ts_preloading_box" style="">
            <div id="ts-preloader-absolute09" style="position:fixed; margin:auto;   border-radius:70px;">
                <div class="tsperloader9" id="tsperloader9_one"></div>
                <div class="tsperloader9" id="tsperloader9_two"></div>
                <div class="tsperloader9" id="tsperloader9_three"></div>
                <div class="tsperloader9" id="tsperloader9_four"></div>
            </div>
        </div>
    </div>
    
    <?php $this->load->view('common/sidemenu'); ?>
    <div class="all-content-wrapper">
        
        <?php $this->load->view('common/titlebar'); ?>
		
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding:0px;">
            <div class="container-fluid" style="margin-top:15px;">
                
               <div class="product-status-wrap mycard">
                   <div class="message error" style="display:none;">
                                                          Process is failed!
                                                          <button type="button" title="close" style="background-color:transparent; border:none; float:right;">X</button>
                                                          <br>
                                                          <br>
                                                      </div>
                                                     <div class="message success s_add" style="display:none;">
                                                          Order successfully sended to placed orders.
                                                         <button type="button" title="close" style="background-color:transparent; border:none; float:right;">X</button>
                                                         <br>
                                                          <br>
                                                      </div>
			    <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                             <div id="myheadtitle" style=" height:55px; line-height:50px;">
                                Placed Orders
                               <ul class="my_quick_bt" style="">
                                    
                                </ul>
                            </div>
                            <div class="panel-body " style="padding-top:0px;">
								   <table class="table mb-none" id="table" data-toggle="table" data-pagination="false" data-show-columns="true" data-show-pagination-switch="true"  data-show-toggle="true"  data-cookie="true"
                          data-show-export="true"  data-toolbar="#toolbar" style="border-bottom: 1px solid #424351;">
                       <thead>
    <tr>
                          <th>Sr. No.</th>
                         
                          <th>Order Date</th>
                          <th>Customer Name</th>
                          <th>Customer Type</th>
                          <th>Phone 1</th>

                          <th>Delivery Date</th>
                          
                          <th>Order Status</th>
                          <th>Delivery Person</th>
                          <th>Action</th>
                          <th>View</th>

                      </tr>
     </thead>
     <tbody id="customer_table">
                      <?php $i = 1; if(isset($orders_list)){ foreach($orders_list as $row){ ?>

                        <tr >

                         <td><?php echo $i++; ?></td>
                          
                         <td><?php echo date('d-M-Y',strtotime($row->online_order_date)); ?></td>
                         <td><?php if($row->order_type == 'membership'){ echo $row->c_first_name.' '.$row->c_last_name;  }else if($row->order_type == 'e_order'){ echo $row->first_name.' '.$row->last_name; } ?></td>
                         <td><?php if($row->order_type  == 'membership'){ echo 'Membership'; }else if($row->order_type == 'e_order'){ echo 'E Customer'; }  ?></td>
                         <td><?php if($row->order_type == 'membership'){ echo $row->c_contact_1; }else if($row->order_type == 'e_order'){ echo $row->contact_1;  }  ?></td>

                         <td><?php echo date('d-M-Y',strtotime($row->delivery_date)); ?></td>
                         <td>
                           <?php if($row->order_status == ''){?> <p class="status" style="background-color:#0088cc; width:80px; text-align:center; color:#ffffff; font-weight:700; border-radius:30px;">New</p> <?php } ?>
                           <?php if($row->order_status == 'placed'){?> <p class="status" style="background-color:#f8cd21; width:80px; text-align:center; color:#ffffff; font-weight:700; border-radius:30px;">Placed</p> <?php } ?>
                           <?php if($row->order_status == 'dispatched'){?> <p class="status" style="background-color:#e335a7; width:80px; text-align:center; color:#ffffff; font-weight:700; border-radius:30px;">Dispatched</p> <?php } ?>
                        <?php if($row->order_status == 'delivered'){?> <p class="status" style="background-color:#019727; width:80px; text-align:center; color:#ffffff; font-weight:700; border-radius:30px;">Delivered</p> <?php } ?>     
                           <?php if($row->order_status == 'canceled'){?> <p class="status" style="background-color:#ff0040; width:80px; text-align:center; color:#ffffff; font-weight:700; border-radius:30px;">Canceled</p> <?php } ?>

                         </td>
                           
                            
                          <td>
                             <select class="form-control"  name="agent"  style="height:25px; padding:0px 5px;" disabled>
                                  <option value="">Delivery Person</option>
                                  <?php if(isset($agent_list)){ foreach($agent_list as $my_row){ ?>
    
                                   <option value="<?php echo $my_row->user_id; ?>"  <?php if($row->delivery_person == $my_row->user_id){ echo 'selected'; } ?> ><?php echo $my_row->name; ?> </option>
                                   <?php } } ?>
                                </select>
                        </td> 
                            
                          <td><select class="form-control" data-order_id="<?php echo $row->online_order_id; ?>" name="change_order_status"  style="height:25px; padding:0px 5px;" disabled>
                                  <option value="">Status</option>
                               <option value="placed" <?php if( $row->order_status == 'placed'){ echo 'selected'; } ?>>Accept </option>
                                <option value="canceled" <?php if( $row->order_status == 'canceled'){ echo 'selected'; } ?>>Cancel</option>
                                </select>
                            </td>      
                            
                         <td> <button type="button" class="btn view_bt" data-tr_id="<?php echo $row->online_order_id; ?>" name="view" style="background-color:#e6e6e6; padding:2px 8px; margin-top:-7px;"><i class="fa fa-eye"></i></button> </td>

                         </tr>
                       
                        <tr class="order_quick_detail_tr" id="<?php echo $row->online_order_id; ?>" style="display:none;" >
                            <td  colspan="10"  style=" padding:0px;">
                                <div class="order_quick_detail"  style="">
                                    <div class="col-md-4">
                                        <p style="padding-bottom:5px; border-bottom:1px solid #2f3135; margin-bottom:8px;">Item Details</p>
                                        
                                         <?php foreach(json_decode($row->online_order_details) as $items){ ?>
								<div class="row" style="padding:10px;  margin-bottom:5px;">
                                    <div class="col-md-6" style="width:120px;">
                                        <img  src="<?php echo base_url(); ?>uploads/product_image/<?php echo $items->item_img; ?>"  style="width:100px; border:1px solid #5b618e; border-radius:5px;">
                                    </div>   
                                    
                                    <div class="col-md-6">
                                        <p style="margin-bottom:2px; color:#ffffff;">Item Name: <?php echo $items->item_name;  ?></p>
                                        <p style="margin-bottom:2px; color:#ffffff;">Quantity: <?php echo $items->item_qty;  ?></p>
                                        <p style="margin-bottom:2px; color:#ffffff;">Total Price: <?php echo $items->item_price;  ?></p>
                                        
                                    </div>
                                 </div>    
                                 
                                 <?php } ?>
                                
                                    </div>
                                     
                                     <div class="col-md-4">
                                       <p style="padding-bottom:5px; border-bottom:1px solid #2f3135; margin-bottom:8px;">Order Details</p>
                                         
                                       <p><label> Order Date:</label> <?php echo date('d-M-Y',strtotime($row->online_order_date)); ?></p>
                                      <p><label> Delivery Date:</label> <?php echo date('d-M-Y',strtotime($row->delivery_date)); ?></p>
                                     
                                      <p><label> Sub Total:</label> <?php echo $row->cart_total; ?></p>
                                      <p><label> Tax:</label> <?php echo $row->order_tax; ?></p>
                                      <p><label> Packing Charge:</label> <?php echo $row->packing_charge; ?></p>
                                     
                                     <?php if($row->point_discount > 0){ ?>
                                      <p><label> Point Discount:</label> <?php echo $row->point_discount; ?></p>
                                     <?php } ?>
                                     
                                     <?php if($row->coupan_discount > 0){ ?>
                                     <p><label> Coupan Discount:</label> <?php echo $row->coupan_discount; ?></p>
                                      <?php } ?>
                                     <p><label> Total Sell:</label> <?php echo $row->total_order_price; ?></p>
                                     
                                      <p><label> Paid Amount:</label> <?php echo $row->paid_amount; ?></p>
                                     
                                     
                                     <p><label> Order Status:</label> <?php if($row->order_status == ''){ echo 'Pending'; }else{ echo $row->order_status;} ?> </p>
                                
                                    </div>
                                </div>
                            </td>
                      
                       </tr>
            <?php }} ?>
              </tbody>
             </table>
							</div>
                              
					</div>
                </div>
               </div>
            </div>
            </div> 
        
           
             <div id="del_alert_action" class="modal modal-edu-general FullColor-popup-DangerModal fade" role="dialog" data-backdrop="static" data-keyboard="false" style="width:460px; margin:auto;">
										 <div class="modal-dialog" style="width:90%;">
												 <div class="modal-content">
														 <div class="modal-close-area modal-close-df">
																 <a class="close" data-dismiss="modal" href="#"><i class="fa fa-close"></i></a>
														 </div>
														 <div class="modal-body" style="padding: 30px 30px; background-color:#363956; text-align:center; color:#ffffff;">
																 <span class="ion-ios-flame-outline" style="font-size:50px; color:#ff4747;"></span>
																 <h2 style="margin-top:6px;">Are You Sure!</h2>
																 <p class="fail_model_p">Do you want to delete this account?</p>
														 </div>
														 <div class="modal-footer danger-md" style=" background-color:#363956; border-top:none;">
																 <button class="btn-transparent btn-red" type="button" data-dismiss="modal" style="width:80px;">No</button>
																 <button data-del_id="" id="del_bt" class="btn-transparent btn-green" type="button"  style="width:80px; ">Yes</button>
					                   </div>
												 </div>
										 </div>
								 </div>

	</div>
<?php $this->load->view('common/footer_script'); ?>
<script type="text/javascript">
		 $(document).ready(function(){
     // set scroll position
		
        
        $(document).on('change','select[name=change_order_status]',function(){
            $('.success').hide();
            
            var status = $(this).val();
            var order_id = $(this).data('order_id');
            var href = window.location.href;
            var return_href = href.substring(href.lastIndexOf('/'));
            
            var this_eliment = $(this);
            
            var agent_id = $(this).parent().parent().find('select[name=agent]').val();
            
            
            if(status == 'placed' && !agent_id){
           
                $(this).parent().parent().find('select[name=agent]').css('border','1px solid red');
                $(this).val('');
            }
            
           
            
            if(status == 'placed' && order_id && agent_id){
                window.location.href = '<?php echo base_url(); ?>orders/order_accept_or_reject/'+order_id+'/'+agent_id+'/'+status;
 
            }else if(status == 'canceled' && order_id){
                window.location.href = '<?php echo base_url(); ?>orders/order_accept_or_reject/'+order_id+'/null/'+status;    
             }
            
            
            
        });
             
         $(document).on('change','select[name=agent]',function(){
            $('.success').hide();
            
            var status = $(this).parent().parent().find('select[name=change_order_status]').val();
            var order_id = $(this).parent().parent().find('select[name=change_order_status]').data('order_id');
            var agent_id = $(this).val();

            if(status == 'placed' && order_id && agent_id){
                window.location.href = '<?php echo base_url(); ?>orders/order_accept_or_reject/'+order_id+'/'+agent_id+'/'+status;
              
            }
            
            
            
        });     
             
        $('.order_quick_detail_tr').hide();   
             
        $('.order_quick_detail_tr td').css('padding','0px');     
             
        $(document).on('click','button[name=view]',function(){
                       
             var tr_id = $(this).data('tr_id'); 
             $('tr[id='+tr_id+']').toggle();
        });    
             
             
        function myhide_msg(){
            $('.s_add').hide();
           $('.s_update').hide();
        }
        setTimeout(myhide_msg, 2000);     
       
});
</script>
</body>
</html>
