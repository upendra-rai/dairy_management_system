<!doctype html>
<html class="fixed">
<head>
		<?php $this->load->view('common/header_link'); ?>
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/modal.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/Lobibox.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/notifications.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>/catalogs/assets/vendor/custom-scrollbar/jquery.mCustomScrollbar.css">
    
    <style type="text/css">
        .form-group{
            padding: 0px 2px;
        }
        
    </style>
</head>
<body>
		<div class="preloader-single shadow-inner mg-b-30" id="my_loader" style="position:fixed; background: rgba(0,0,0,0.8); width:100%; height:100vh; z-index: 9999; display:none;">
        <div class="ts_preloading_box" style="">
            <div id="ts-preloader-absolute09" style="position:fixed; margin:auto;   border-radius:70px;">
                <div class="tsperloader9" id="tsperloader9_one"></div>
                <div class="tsperloader9" id="tsperloader9_two"></div>
                <div class="tsperloader9" id="tsperloader9_three"></div>
                <div class="tsperloader9" id="tsperloader9_four"></div>
            </div>
        </div>
    </div>
    
    <?php $this->load->view('common/sidemenu'); ?>
    <div class="all-content-wrapper">
        
        <?php $this->load->view('common/titlebar'); ?>
		
        
           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding:0px; margin-top:10px;">
            <div class="container-fluid">
               <div class="product-status-wrap mycard">
			    <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div id="myheadtitle" style=" margin-bottom:0px;">
                               Product List
                               <ul class="my_quick_bt" style="">
                                    
                                    <li>
                                        <a href="<?php echo base_url(); ?>team">
                                            <i class="ion-ios-undo-outline"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="panel-body" style="padding-left:0px; padding-right:0px;   padding-top:15px; padding-bottom:0px;">
								 <table class="table mb-none" id="table" data-toggle="table" data-pagination="true" style="border-bottom: 1px solid #424351;">
									 <thead>
									   	<tr>
											   <th>Sr no</th>
										     <th>Image</th>
											   <th>Product Name</th>
                                             
												 <th>Unit</th>
												 <th>Price</th>
                                             <th>Category</th>
                                             <th>Sub Category</th>
											   <th class="hidden-phone">Status</th>
                                            <th>Linked Dairy Product</th>
                                            
											   <th>Edit</th>
											   <th>Action</th>
										</tr>
									</thead>
									<tbody>
										  <?php $i = 1; if(isset($product_list)){ foreach($product_list as $row){ ?>
                          <tr>
														   <td><?php echo $i++; ?></td>
														  <td style="width:110px; padding:4px; text-align:center;"><img src="<?php echo base_url(); ?>uploads/product_image/<?php echo $row->product_img; ?>" style="border-radius:2px; border:1px solid #45496d;" height="20" ></td>
                          	                              <td><?php echo $row->e_product_name; ?></td>
														  <td><?php echo $row->product_unit; ?></td>
												          <td><?php echo $row->product_unit_price; ?></td>
                                                          <td><?php echo $row->product_category_name; ?></td>
                                                         <td><?php echo $row->product_sub_category_name; ?></td>
														<td><?php echo $row->product_status; ?></td>
                                                        <td></td>
														  <td style=" text-align:center;"><button class="btn btn-primary" id="edit_bt"  data-edit_id="<?php echo $row->e_product_id; ?>" data-category="<?php echo $row->my_product_category_id; ?>" data-sub_category="<?php echo $row->my_product_sub_category_id; ?>"  style="color:#248afd; background-color:#f2f2f2; border:1px solid #e2e2e2;"><i class="fa fa-pencil"></i></button></td>
										      	  <td style="text-align:center;"><button type="button" class="btn btn-primary" id="confirm_del_action" data-confirm_del_id="<?php echo $row->e_product_id; ?>" style="color:#ff4747; background-color:#f2f2f2; border:1px solid #e2e2e2;"><i class="fa  fa-times-circle"></i></button></td>
                          </tr>
										<?php }} ?>
									</tbody>
								</table>	
						  </div>
                              
					</div>
                </div>
               </div>
            </div>
            </div> 
            
        
			          <div id="del_alert_action" class="modal modal-edu-general FullColor-popup-DangerModal fade" role="dialog" data-backdrop="static" data-keyboard="false" style="width:460px; margin:auto;">
										 <div class="modal-dialog" style="width:90%;">
												 <div class="modal-content">
														 <div class="modal-close-area modal-close-df">
																 <a class="close" data-dismiss="modal" href="#"><i class="fa fa-close"></i></a>
														 </div>
														 <div class="modal-body" style="padding: 30px 30px; background-color:#363956; text-align:center; color:#ffffff;">
																 <span class="ion-ios-flame-outline" style="font-size:50px; color:#ff4747;"></span>
																 <h2 style="margin-top:6px;">Are You Sure!</h2>
																 <p class="fail_model_p">Do you want to delete this account?</p>
														 </div>
														 <div class="modal-footer danger-md" style=" background-color:#363956; border-top:none;">
																 <button class="btn-transparent btn-red" type="button" data-dismiss="modal" style="width:80px;">No</button>
																 <button data-del_id="" id="del_bt" class="btn-transparent btn-green" type="button"  style="width:80px; ">Yes</button>
					                   </div>
												 </div>
										 </div>
								 </div>

	</div>
<?php $this->load->view('common/footer_script'); ?>
<script src="<?php echo base_url(); ?>/catalogs/assets/javascripts/image-compressor.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/Lobibox.js"></script>
<script src="<?php echo base_url(); ?>/catalogs/assets/modal/notifications/notification-active.js">
</script>
 <script src="<?php echo base_url(); ?>/catalogs/js/image_compress/image-compressor.js"></script>    
<script src="<?php echo base_url(); ?>/catalogs/assets/vendor/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript">
		 $(document).ready(function(){
     // set scroll position
		// rediren for update section
    $(document).on('click','button[id=edit_bt]',function(){
              var edit_id = $(this).data("edit_id");
							var scroll_position = $('html').scrollTop()
              // category id and cetegory id selected
							var url = window.location.href;
			 			  var segments = url.split( '/' );

							var category_id = $(this).data("category");
							var subcategory_id = $(this).data("sub_category");
        
                      if(!subcategory_id){
                          subcategory_id = 0;
                      }
       // alert(category_id);
              var redirect_link  = '<?php echo base_url(); ?>product_e/edit_product/'+category_id+'/'+subcategory_id+'/'+edit_id+'/0';

							window.location.href = redirect_link;

		});
// delete functionality
    $(document).on('click','button[id=confirm_del_action]',function(){
						 var confirm_del_id = $(this).data("confirm_del_id");
						 $('#del_bt').data('del_id',confirm_del_id);
						 $('#del_alert_action').modal("toggle");
		});

		$(document).on('click','button[id=del_bt]',function(){
			   var del_id = $(this).data("del_id");
							$.ajax({
		              url : '<?php echo base_url(); ?>/product_e/del_product',
								  method: 'POST',
									data:{del_id: del_id},
									success:function(data){
										if(data === 'success'){
											window.location.href = window.location.href;
										}
									}
							});
	    });
});
</script>
</body>
</html>
